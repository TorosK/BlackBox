public class Random {

}
