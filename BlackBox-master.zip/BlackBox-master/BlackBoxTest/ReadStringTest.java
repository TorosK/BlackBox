import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

// Doesn't concatinate lines separated by empty rows / lines / line break
// Concatinates without creating spaces when concatinating two lines. So the
// words on both lines are combined without space in between them.
// Empty text file gives no faults. It works.

/*
   If the given file-path does not exist the pathname itself is returned as half a string.
   We speculate that it is sent to the upperHalf() method and is returned as either null or a string.
*/

public class ReadStringTest{

    /*
    readString
    public static String readString(String filename)
    Reads From file and concatinates the lines to a long string
    Parameters:
    filename - The path to the file
    Returns:
    A String of concatinated lines from the file
    */

    @Test
    void readStringTest001(){
        Iqh.readString(test);
    }
}