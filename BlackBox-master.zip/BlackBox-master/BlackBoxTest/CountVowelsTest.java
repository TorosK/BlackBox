import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// We can conclude that the letter "y" is not counted as a vowel
// "ä" is counted as 2 vowels (ä = 2 ä´s). VowelCounter is incremented by 2 instead of 1.
// Capital vowels are not counted as vowels.
// All capital letters are not detected by vowelCounter
// Foreign Exotic vowels (Ø ø Ü ü) and digits (0123...) are not counted as vowels

class CountVowelsTest {

    @Test
    void countVowelsTest(){
        assertEquals(2, Iqh.countVowels("Toros"));
    }
    @Test
    void countVowelsTest2(){  // "Y" is not counted
        assertEquals(18, Iqh.countVowels("aoueiyaoueiyaoueiy")); // fail. Actual: 15
    }
    @Test
    void countVowelsTest3(){ // "Y" is not counted
        assertEquals(6, Iqh.countVowels("aoueiy"));  // All 6 vowels english vowels  FAIL. Actual: 5
    }
    @Test
    void countVowelsTest4(){
        assertEquals(5, Iqh.countVowels("aeiouz"));
    }
    @Test
    void countVowelsTest5a() {
        assertEquals(1, Iqh.countVowels("A")); // capital letter not counted
    }
    @Test
    void countVowelsTest5b(){
        assertEquals(1, Iqh.countVowels("a"));
    }
    @Test
    void countVowelsTest6a(){
        assertEquals(1, Iqh.countVowels("E"));
    }
    @Test
    void countVowelsTest6b(){
        assertEquals(1, Iqh.countVowels("e"));
    }
    @Test
    void countVowelsTest7a(){
        assertEquals(1, Iqh.countVowels("I"));
    }
    @Test
    void countVowelsTest7b(){
        assertEquals(1, Iqh.countVowels("i"));
    }
    @Test
    void countVowelsTest8a(){
        assertEquals(1, Iqh.countVowels("O"));
    }
    @Test
    void countVowelsTest8b(){
        assertEquals(1, Iqh.countVowels("o"));
    }
    @Test
    void countVowelsTest9a(){
        assertEquals(1, Iqh.countVowels("U"));
    }
    @Test
    void countVowelsTest9b(){
        assertEquals(1, Iqh.countVowels("u"));
    }
    @Test
    void countVowelsTest10a(){
        assertEquals(1, Iqh.countVowels("Y")); // y should be vowel. But it isn't
    }
    @Test
    void countVowelsTest10b(){
        assertEquals(1, Iqh.countVowels("y")); // y should be vowel. But it isn't
    }
    @Test
    void countVowelsTest11a(){
        assertEquals(1, Iqh.countVowels("Å"));
    }
    @Test
    void countVowelsTest11b(){
        assertEquals(1, Iqh.countVowels("å"));
    }
    @Test
    void countVowelsTest12a(){
        assertEquals(1, Iqh.countVowels("Ä"));
    }
    @Test
    void countVowelsTest12b(){
        assertEquals(1, Iqh.countVowels("ä")); // "ä" is counted twice
    }

    @Test
    void countVowelsTest13a(){
        assertEquals(1, Iqh.countVowels("Ö"));
    }

    @Test
    void countVowelsTest13b(){
        assertEquals(1, Iqh.countVowels("ö"));
    }

    @Test
    void countVowelsTest14a(){
        assertEquals(0, Iqh.countVowels("Z"));
    }

    @Test
    void countVowelsTest14b(){
        assertEquals(0, Iqh.countVowels("z"));
    }
    @Test
    void countVowelsTest15(){
        assertEquals(3, Iqh.countVowels("abcdefghijk"));
    }
    @Test
    void countVowelsTest16(){
        assertEquals(1, Iqh.countVowels("lmnopqrst"));
    }
    @Test
    void countVowelsTest17(){
        assertEquals(2, Iqh.countVowels("uvwxyz")); // y is the problem
    }
    @Test
    void countVowelsTest18(){
        assertEquals(0, Iqh.countVowels("bcdfghjklmnpqrstvwxz"));
    }
    @Test
    void countVowelsTest19(){
        assertEquals(3, Iqh.countVowels("åäö")); // actual 4 because "ä" is counted twice
    }
    @Test
    void checkCapitalLetter(){
        assertEquals(0, Iqh.countVowels("ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ")); // Hypothesis confirmed, no capital letters were counted
    }
    @Test
    void checkNumbers(){
        assertEquals(0, Iqh.countVowels("0123456789")); // Hypothesis confirmed, no numbers were counted
    }
    @Test
    void checkEdgeCases01(){
        assertEquals(4, Iqh.countVowels("Ø ø Ü ü ")); // Foreign vowels and spaces are not counted as vowels
    }
    @Test
    void checkEdgeCases02(){
        assertEquals(0, Iqh.countVowels("ÀÁÂÃÜƳȤ")); // Foreign vowels are not counted as vowels
    }
    @Test
    void checkEdgeCases03(){
        assertEquals(0, Iqh.countVowels("áàâã")); // Foreign vowels are not counted as vowels
    }
    @Test
    void checkEdgeCases04(){
        assertEquals(0, Iqh.countVowels("āäảẚ")); // Foreign vowels are not counted as vowels
    }
    @Test
    void checkEdgeCases05(){
        assertEquals(0, Iqh.countVowels("ầẽȅễ")); // Foreign vowels are not counted as vowels
    }
    @Test
    void checkEdgeCases06(){
        assertEquals(0, Iqh.countVowels("ḱòóôõ")); // Foreign vowels are not counted as vowels
    }
    @Test
    void checkEdgeCases07(){
        assertEquals(0, Iqh.countVowels("śùúûũ")); // Foreign vowels are not counted as vowels
    }
    @Test
    void checkEdgeCases08(){
        assertEquals(0, Iqh.countVowels("-_+?!\"#¤%&(/)=?")); // Foreign vowels are not counted as vowels
    }
}