import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// when randomizing lowerCase alphabetic characters (String of length 15 or above) it adds the third char to the end of the randomized list
public class ScatterStringTest {
    /*
    scatterString
    public static String scatterString(String in)
    Returns the String with all the chars in randomized order
    Parameters:
    in - The String to processed
    Returns:
    A string with the characters from the input string in a random order
    */

    @Test
    void scatterStringTest001() { // String should be 29 long. But it is 30 long
        String result = Iqh.scatterString("abcdefghijklmnopqrstuvwxyzåäö"); // adds the third char to the end of the randomized list
        System.out.println(result);
        assertTrue(result.length() == 29);
    }
    @Test
    void scatterStringTest002() { // loops through method 001 five times
        for(int i = 0; i <= 5; i++) {
            String result = Iqh.scatterString("abcdefghijklmnopqrstuvwxyzåäö");
            /* Conclusion: Method takes the third letter from randomized string and re-adds it
             at the end of the full randomized string */
            System.out.println(result);
        }
    }
    @Test
    void scatterStringTest003() { // loops through method 001 five times
        for(int i = 0; i <= 3; i++) {
            String result = Iqh.scatterString("Aa Aa Aa Aa");
            System.out.println(result);
        }
    }
    @Test
    void scatterStringTest004() {
        String result = Iqh.scatterString("0123456789");
        System.out.println(result);
    }

    @Test
    void scatterStringTest005() {
        String result = Iqh.scatterString("012345678901234567890123456789");
        System.out.println(result);
    }
    @Test
    void scatterStringTest006(){ // Method constantly prints and extends a string 30 times in a row
        System.out.println("");

        String myString = "AB";
        for(int i = 0; i <=30; i++) {
            String result = Iqh.scatterString(myString);
            System.out.println(result);
            myString = myString + "C";
        }
        System.out.println("");
    }
    @Test
    void scatterStringTest007() {
        String result = Iqh.scatterString(" _-+?!#@()[]{}¤%&/=£$€\"´`_");
        System.out.println(result);
    }
    @Test
    void scatterStringTest008() {
        String result = Iqh.scatterString("ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ");
        System.out.println(result);
    }
    @Test
    void scatterStringTest009() {
        String result = Iqh.scatterString("aABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ");
        System.out.println(result);
    }
    @Test
    void scatterStringTest010(){ // Method constantly prints and extends a string 30 times in a row
        System.out.println("");

        String myString = "ab";
        for(int i = 0; i <=30; i++) {
            String result = Iqh.scatterString(myString);
            System.out.println(result);
            myString = myString + "c";
        }
        System.out.println("");
    }
    @Test
    void scatterStringTest011() { // should be 15 chars but returns 16 chars
        String result = Iqh.scatterString("abcdefghijklmno"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest012(){ // Re-make of method 006 too check if error is dependent on amount of unique characters
        System.out.println("");

        String myString = "AB";
        for(int i = 0; i <=7; i++) {
            String result = Iqh.scatterString(myString);
            System.out.println(result);
            myString = myString + "C" + "D" + "E";
        }
        System.out.println("");
    }
    @Test
    void scatterStringTest013() { // 8 chars
        String result = Iqh.scatterString("abcdefgh"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest014() { // 11 chars
        String result = Iqh.scatterString("abcdefghijk"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest015() { // 10 chars
        String result = Iqh.scatterString("abcdefghij"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest016() { // 12 chars
        String result = Iqh.scatterString("abcdefghijkl"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest017() { // 13 chars
        String result = Iqh.scatterString("abcdefghijklm"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest018() { // 14 chars - returns 14
        String result = Iqh.scatterString("abcdefghijklmn"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest019() { // 15 chars but returns 16
        String result = Iqh.scatterString("abcdefghijklmno"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest020() { // 16 chars but returns 17
        String result = Iqh.scatterString("abcdefghijklmnop"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest021() { // 16 chars but returns 17
        String result = Iqh.scatterString("aaaaaaaaaaaaaaaa"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest022() { // 16 chars - returns 16
        String result = Iqh.scatterString("AAAAAAAAAAAAAAAA"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest023() { // 16 chars - returns 16
        String result = Iqh.scatterString("1234567890123456"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest024() { // 16 chars but returns 17
        String result = Iqh.scatterString("aAAaaaaaaaaaaaaa"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest025() { // 16 chars but returns 17
        String result = Iqh.scatterString("aA7aaaaaaaaaaaaa"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest026() { // 16 chars - returns 16
        String result = Iqh.scatterString("1a34567890123456"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest027() { // 16 chars - returns 16
        String result = Iqh.scatterString("abcdeABCDE123456"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest028() { // 21 chars - returns 21
        String result = Iqh.scatterString("abcdabcdabcdabcd"); // attempts to locate error by trying upper and lower case letters as well as numbers
        System.out.println(result);
        String secondResult = Iqh.scatterString("ABCDABCDABCDABCD");
        System.out.println(secondResult);
        String thirdResult = Iqh.scatterString("abcdabcd12341234");
        System.out.println(thirdResult);
    }
    @Test
    void scatterStringTest029() { // 16 chars - returns 16
        String result = Iqh.scatterString("AbcdeABCDE123456"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
    @Test
    void scatterStringTest030() { // 16 chars - returns 16
        String result = Iqh.scatterString("1bcdeABCDE123456"); // adds the third char to the end of the randomized list
        System.out.println(result);
    }
}