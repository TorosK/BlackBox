import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

/*
CountConsonantsTest
Conclusion: Method properly counts non-capital consonants EXCEPT for
vowel: "y" which is counted as a consonant.
All capital vowels are counted as consonants!
The swedish letter "ä" seems to be counted as two vowels (ä = ä, ä)
but capital ä (Ä) is counted as a consonant as all capital letters are.
String "y" and "Y" are counted as consonants.
All characters that are not vowels seem to be counted as consonants...

The case might be that the same conditions are used for countVowels() and countConsonants().
This could mean that all characters not counted as vowels are considered consonants
which could explain why characters like numbers and special signs and characters
(such as "y" and "ä") are counted as vowels.
Further examination is highly recommended.

Digits are counted as consonants.
Special characters are also counted as consonants
*/

public class CountConsonantsTest {
    @Test
    void countConsonantsTest001(){
        assertEquals(3, Iqh.countConsonants("Toros"));
    }

    // checks alphabetic String characters, both lower and upper case letters, for consonants.
    // Manual check
    @Test
    void countConsonantsTest002(){
        ArrayList<String> consonants = new ArrayList<>();
        Collections.addAll(consonants, "a", "A", "b", "B", "c", "C", "d", "D", "e", "E",
                "f", "F", "g", "G", "h", "H", "i", "I", "j", "J", "k", "K", "l", "L", "m", "M",
                "n", "N", "o", "O", "p", "P", "q", "Q", "r", "R", "s", "S", "t", "T", "u", "U",
                "v", "V", "w", "W", "x", "X", "y", "Y", "z", "Z", "å", "Å", "ä", "Ä", "ö", "Ö");
        for (String element : consonants) {
            System.out.println(element + " counts as " + Iqh.countConsonants(element) + " consonants");
        }

    }

    // Checks digits
    @Test
    void countConsonantsTest003(){
        ArrayList<String> consonants = new ArrayList<>();
        Collections.addAll(consonants, "1", "2", "3", "4", "5", "6", "7", "8", "9"); // Numbers are counted as consonants
        for (String element : consonants) {
            System.out.println(element + " counts as " + Iqh.countConsonants(element) + " consonants");
        }
    }

    // Checks special characters.
    @Test
    void countConsonantsTest004(){
        ArrayList<String> consonants = new ArrayList<>();
        Collections.addAll(consonants, "!", "?", "@", "#", "¤", "%", "&", "/", "(", ")", "=", "£", "$", "{", "}"); // Spec characters counted as consonants
        for (String element : consonants) {
            System.out.println(element + " counts as " + Iqh.countConsonants(element) + " consonants");
        }
    }

    @Test
    void countConsonantsTest005(){
        int result = Iqh.countConsonants("y"); // "y" counted incorrectly
        assertEquals(0, result);
    }

    @Test
    void countConsonantsTest006(){
        int result = Iqh.countConsonants("ä"); // "ä" counted incorrectly
        assertEquals(0, result);
    }

    @Test
    void countConsonantsTest007(){
        int result = Iqh.countConsonants("a");
        assertEquals(0, result);
    }

    @Test
    void countConsonantsTest008(){
        int result = Iqh.countConsonants("b");
        assertEquals(1, result);
    }
}
