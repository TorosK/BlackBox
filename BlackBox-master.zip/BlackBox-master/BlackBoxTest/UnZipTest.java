import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class UnZipTest {
    /*
    unzip
    public static String[] unzip(String in)
    Unzips a string meaning abddef -> ["ace", "bdf"]
    Parameters:
    in - The string to be processed
    Returns:
    an Array of size 2 with the two strings
    */

    // Method "unzip" doesn't seem to be reachable or doesn't exist. Complete implementation recommended.


    /*
    @Test
    void unZipTest001() {
        String[] result = Iqh.unzip("Abcdef"); // Seems to work as intended
        System.out.println(result);
        assertEquals("Ace", "bdf", result);
    }
    */
}
