import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

 /*
 When the second to first AND the second to last letters are the same letter (case-sensitive)
 they are both copied and placed in front of and after the word in question.
 (Example:  word "Anna" results in "nannAn")
 */

// Attempting to invert one single character doesn't work

// Aside from previously mentioned issues the method seems to work as intended and inverts strings properly

public class InvertTest {
    /*
    invert
    public static String invert(String in)
    Inverts the given String
    Parameters:
    in - The String to processed
    Returns:
    The inString inverted
    */

    @Test
    void invertTest001(){
        String test = "Toros";
        System.out.println(Iqh.invert(test));
    }

    @Test
    void invertTest002(){
        String test = "Julius";
        System.out.println(Iqh.invert(test));
    }

    @Test
    void invertTest003(){
        String test = "Emily";
        String result = Iqh.invert(test);
        System.out.println(Iqh.invert(test));
        assertEquals("ylimE", result);
    }
    @Test
    void invertTest004(){
        String test = "Jehanea";
        System.out.println(Iqh.invert(test));
    }

    // Error String index out of range: 1
    @Test
    void invertTest005(){
        String test = "P";
        String result = Iqh.invert(test);
        assertEquals("P", result);
    }

    @Test
    void invertTest006(){
        String test = "PP";
        System.out.println(Iqh.invert(test));
    }
    @Test
    void invertTest007(){
        String test = "PPP";
        System.out.println(Iqh.invert(test));
    }

    @Test
    void invertTest008(){
        String test = "anna";
        System.out.println(Iqh.invert(test));
    }

    @Test
    void invertTest009(){
        String test = "aNnaanNa";
        System.out.println(Iqh.invert(test) + " Batman!");
    }

    @Test
    void invertTest010(){
        String test = "abcdefghijklmnopqrstuvwxyzåäö";
        System.out.println(Iqh.invert(test));
    }

    @Test
    void invertTest011(){
        String test = "0123456789";
        System.out.println(Iqh.invert(test));
    }

    @Test
    void invertTest012(){
        String test = " _-+?!#@()[]{}¤%&/=£$€\"´`";
        System.out.println(Iqh.invert(test));
    }
}
