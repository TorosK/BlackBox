import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// zip() stops zipping two Strings when one of the Strings runs out of chars.
// If one String is 20 long and the other is 10 long, the characters 11-20 in
// the longer String are not printed out, regardless if it is the first or the second String argument.

public class ZipTest {
    /*
    zip
    public static String zip(String in, String in2)
    Zips two strings together "Abc, def" -> "Adbecf" First cher from the first argument.
    Parameters:
    in - The first string to be zipped
    in2 - The second string to be zipped
    Returns:
    the Zipped string
    */

    @Test
    void zipTest001() { // korrekt
        String result = Iqh.zip("Abc", "def"); // Seems to work as intended
        System.out.println(result);
        assertEquals("Adbecf", result);
    }

    @Test
    void zipTest002() { // Zipped string seems to end when one of the two strings end.
        String result = Iqh.zip("abcdefghijklmnopqrstuvwxyzåäö", "0123456789");
        System.out.println(result);
    }

    @Test
    void zipTest003() {
        String result = Iqh.zip("123", "234");
        System.out.println(result);
        assertEquals("122334", result);
    }

    @Test
    void zipTest004() { // Method works predictably
        String result = Iqh.zip("!?:=)#¤\"", "98765432");
        System.out.println(result);
        assertEquals("!9?8:7=6)5#4¤3\"2", result);
    }

    @Test
    void zipTest005() {
        String result = Iqh.zip("Ä", "Ö");
        System.out.println(result);
        assertEquals("ÄÖ", result);
    }

    @Test
    void zipTest006() {
        String result = Iqh.zip("", "");
        System.out.println(result);
        assertEquals("", result);
    }

    @Test
    void zipTest007() { // String of null gives error. But perhaps it should.
        String result = Iqh.zip(null, null);
        System.out.println(result);
        assertEquals(null, result);
    }

    @Test
    void zipTest008() {
        String result = Iqh.zip("Smör gås!!!", "Vad ä det??");
        System.out.println(result);
        assertEquals("SVmaödr  äg ådse!t!?!?", result);
    }

    @Test
    void zipTest009() {
        String result = Iqh.zip("_-+", "   ");
        System.out.println(result);
        assertEquals("_ - + ", result);
    }
    @Test
    void zipTest010() {
        String result = Iqh.zip("!", "?");
        System.out.println(result);
        assertEquals("!?", result);
    }

    @Test
    void zipTest011() {
        String result = Iqh.zip(" JA!", " NEJ");
        System.out.println(result);
        assertEquals("  JNAE!J", result);
    }

    // Test with smaller string first
    @Test
    void zipTest012() { // Zipped string seems to end when one of the two strings end.
        String result = Iqh.zip("0123456789", "abcdefghijklmnopqrstuvwxyzåäö");
        System.out.println(result);
    }
}
