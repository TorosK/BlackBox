import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class RemoveVowelsTest {
    /*
    removeVowels
    public static String removeVowels(String in)
    Remove the vowels from at text
    Parameters:
    in - The string to be processed
    Returns:
    the string without Vowels

    Conclusion:
    Method "removeVowels" doesn't work as documented or is completely unreachable. Complete method implementation
    is highly recommended.*/

    /* // Remove comments when ready to test
    @Test
    void removeVowelsTest001() {
        String result = Iqh.removeVowels("Abcdef");
        System.out.println(result);
        assertEquals("Abcdf", result);
    }
    @Test
    void removeVowelsTest002() {
        String result = Iqh.removeVowels("abcdefghijklmnopqrstuvwxyzåäö");
        System.out.println(result);
        assertEquals("abcdfghjklmnpqrstvwxyz", result);
    }
    @Test
    void removeVowelsTest003() {
        String result = Iqh.removeVowels("0123456789");
        System.out.println(result);
        assertEquals("0123456789", result);
    }
    @Test
    void removeVowelsTest004() {
        String result = Iqh.removeVowels(" _-+?!#@()[]{}¤%&/=£$€\"´`_");
        System.out.println(result);
        assertEquals(" _-+?!#@()[]{}¤%&/=£$€\"´`_", result);
    }
    @Test
    void removeVowelsTest005() {
        String result = Iqh.removeVowels("ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ");
        System.out.println(result);
        assertEquals("BCDFGHJKLMNPQRSTVWXYZ", result);
    }
    */
}