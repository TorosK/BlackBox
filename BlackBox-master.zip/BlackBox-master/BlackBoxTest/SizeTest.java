import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Test results show that this method is found without faults
// Works as advertized

public class SizeTest {
    /*
    size
    public static int size(String in)
    return the length of the given String
    Parameters:
    in - The String to processed
    Returns:
    the length of the String
    */

    // Tests input of a String "7" (int is converted to String)
    @Test
    void sizeTest001(){
        String stringSize = "";
        System.out.println("The length of the string at size 0 is: " + Iqh.size(stringSize));
        for (int i = 1; i <= 20; i++) {
            stringSize = stringSize + "7";
            System.out.println("The length of the string at size " + i + " is: " + Iqh.size(stringSize));
        }
        System.out.println("");
    }

    // Tests input of int 7 (int is converted to String)
    @Test
    void sizeTest002(){
        String stringSize = "";
        System.out.println("The length of the string at size 0 is: " + Iqh.size(stringSize));
        for (int i = 1; i <= 20; i++) {
            stringSize = stringSize + 7;
            System.out.println("The length of the string at size " + i + " is: " + Iqh.size(stringSize));
        }
        System.out.println("");
    }

    // Checks all alphabetic characters
    @Test
    void sizeTest003(){
        String stringSize = "abcdefghijklmnopqrstuvwxyzåäö";
        System.out.println("The length of the string at size 29 is: " + Iqh.size(stringSize));
        System.out.println("");
    }

    // Checks all digits
    @Test
    void sizeTest004(){
        String stringSize = "0123456789";
        int result = Iqh.size(stringSize);
        assertEquals(10, result);
    }

    // Checks many special characters
    @Test
    void sizeTest005(){
        String stringSize = " _-+?!#@()[]{}¤%&/=£$€\"´`";
        System.out.println("The length of the string at size 25 is: " + Iqh.size(stringSize));
    }
}
